self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "4d0d939e67cb7f81bca60af4d68bab0f",
    "url": "/wiki/index.html"
  },
  {
    "revision": "6fa52f352571d2ff193f",
    "url": "/wiki/static/css/2.d9b65b65.chunk.css"
  },
  {
    "revision": "8a1ba8461bcda2a48927",
    "url": "/wiki/static/css/main.80af8ce2.chunk.css"
  },
  {
    "revision": "6fa52f352571d2ff193f",
    "url": "/wiki/static/js/2.49d43d17.chunk.js"
  },
  {
    "revision": "c64c486544348f10a6d6c716950bc223",
    "url": "/wiki/static/js/2.49d43d17.chunk.js.LICENSE.txt"
  },
  {
    "revision": "8a1ba8461bcda2a48927",
    "url": "/wiki/static/js/main.f0be4aa5.chunk.js"
  },
  {
    "revision": "f4de572bed9b4948ee74",
    "url": "/wiki/static/js/runtime-main.45cbe894.js"
  },
  {
    "revision": "1f663bbef1dfd399e16d137dc3788340",
    "url": "/wiki/static/media/Akatsuki.1f663bbe.png"
  },
  {
    "revision": "b0b9fd49493dbeaea57bebd57bbda3a3",
    "url": "/wiki/static/media/Kage.b0b9fd49.png"
  },
  {
    "revision": "d17f7be2278ed3de7fb6aa571e0c32bb",
    "url": "/wiki/static/media/Otsutsuki.d17f7be2.png"
  },
  {
    "revision": "1fe94c5cbfc23db19388dcf35af26445",
    "url": "/wiki/static/media/graduacao.1fe94c5c.png"
  },
  {
    "revision": "f56b2e328c3b0a5f27e0e4f06624631c",
    "url": "/wiki/static/media/items.f56b2e32.png"
  },
  {
    "revision": "d0d7d7a92ab3d6555d0de496b51e30d8",
    "url": "/wiki/static/media/items_game.d0d7d7a9.png"
  },
  {
    "revision": "ccf6d38078edf5da33c77691b1f70404",
    "url": "/wiki/static/media/konoha.ccf6d380.jpg"
  },
  {
    "revision": "32c14c1069919568f3cee31946ca2012",
    "url": "/wiki/static/media/logo.32c14c10.png"
  },
  {
    "revision": "e1c0a9228e3956cb350ce011845e0a2e",
    "url": "/wiki/static/media/orgs.e1c0a922.png"
  },
  {
    "revision": "eaa8480f5267ddcef6a9c79cf0fb3338",
    "url": "/wiki/static/media/personagens.eaa8480f.png"
  }
]);